import { Component, OnInit } from '@angular/core';
import { environment } from '@environment';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  name = 'Angular';
  apiUrl = 'https://www.techiediaries.com/api/data.json';
  apiUrl1 = environment.api + "Users/Home";

  


 // constructor() { }
 constructor(private httpClient: HttpClient){}

  ngOnInit(): void {
    console.log("aa", environment.api + "Users/Home");
    this.fetchData();
  }

  private fetchData(){
    //const abc = this.httpClient.get(this.apiUrl).toPromise();
    const promise = this.httpClient.get(this.apiUrl).toPromise();
    const promise1 = this.httpClient.get("https://localhost:44368/api/Values/AAA").toPromise();
    //const promise1 = this.httpClient.get(this.apiUrl).toPromise();
    console.log("結果",promise); 
    console.log("結果2",promise1); 
    console.log(promise);  
    promise.then((data)=>{
      // console.log("Promise resolved with: " + JSON.stringify(data));
      console.log("Promise resolved with: " + JSON.stringify(data));
      promise1.then((data)=>{
        console.log("Promise resolved with2: " + JSON.stringify(data));
      }).catch((error)=>{
        console.log("Promise rejected with " + JSON.stringify(error));
       // alert("err"+ JSON.stringify(error));
      });

      // alert(JSON.stringify(data));
      // alert("ok");
    }).catch((error)=>{
      console.log("Promise rejected with " + JSON.stringify(error));
     // alert("err"+ JSON.stringify(error));
    });  

  }


}

export interface Notificatie {
  id:number;
  message:string;
  icon:string;
}