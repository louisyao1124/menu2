import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  template: `<h1>i am the home page!</h1>`
})
export class HomeComponent implements OnInit {

  constructor() {}

  ngOnInit() {}

}
